This program has 4 data structures built and tested with times and random items.

* ArrayPriorityQueue
* HeapPriorityQueue
* UnorderedPriorityQueue

2 interfaces